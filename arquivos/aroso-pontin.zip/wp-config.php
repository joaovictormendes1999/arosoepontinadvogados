<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'aroso-pontin' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'pOp!^Cf|Z^}@{3AW<>ita`!*yet~IrN7urkAYS,FgdQ-.E1yB:3lj+F711F9gZ{@' );
define( 'SECURE_AUTH_KEY',  'Dgx5L$lS_V m3}vFmZX_}5>:a]bxX3cQiU1I8S$2fFqMOHH;|/aIXI4tjUSc!186' );
define( 'LOGGED_IN_KEY',    'AmW~hd$lL=&l?aX>9EiBZ%_Oun @UQsSZ:MuCfF.ZXlKY)PeX?*6foxJ%2e14X=b' );
define( 'NONCE_KEY',        '^8F!l5v18A1N@kN=}6(Ek^9^r`wgoMl*>lk0zG KT7fOxm4H!$[xMPm  5geW3 s' );
define( 'AUTH_SALT',        'C#s<hlH&DqgTU|j0pN~e{%G+e$zB+!:.rg;r3-ovgf|ZTb7t`,_vB:E@U|;B/B-}' );
define( 'SECURE_AUTH_SALT', 'DV{g=b9c^$IO5Av^HiQHLyP=1Vnj;QeIIVi?rQ@^Tk(wj3q~@Fk<iQD<QK[3<W55' );
define( 'LOGGED_IN_SALT',   ':?61U;;Vrby9=vMj?$1,A%g?NDe!1wNv9}+rdE(|0zsz]#T=].1y*S<cISJ;v<zS' );
define( 'NONCE_SALT',       ' -FOyYTeF-?)<;(Sjl7WFEG[I.a6BxUZge!D^45&b`Plr&BH9O>J^D~p2Bt%h5o{' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
ini_set('display_errors','Off');

ini_set('error_reporting', E_ALL );

define('WP_DEBUG', false);

define('WP_DEBUG_DISPLAY', true);



define( 'ALLOW_UNFILTERED_UPLOADS', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
